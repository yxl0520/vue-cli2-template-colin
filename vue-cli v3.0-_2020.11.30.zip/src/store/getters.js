/*
 * @Description: 专门对store的state计算返回
 * @Author: Colin
 * @Date: 2020-05-11 15:16:56
 */
export default {
  // todo
}
