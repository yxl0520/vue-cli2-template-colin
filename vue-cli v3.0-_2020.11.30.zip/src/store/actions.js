/*
 * @Description: 封装 获取相应 数据、状态值 方法
 * @Author: Colin
 * @Date: 2020-05-11 15:17:22
 */
