export default {
  // 更新加载状态
  // showLoading (state, payload) {
  //   state.loading = payload
  // }
};
