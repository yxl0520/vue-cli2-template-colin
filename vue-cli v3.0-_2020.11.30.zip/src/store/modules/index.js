import vuexModuleDemo from './vuexModuleDemo'

export default {
  vuexModuleDemo
}
