const state = {
  user: 'demo',
  loading: false
}

export default state
